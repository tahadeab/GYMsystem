﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcciss_GymSystem
{
    internal  class ConnectPath
    {
        public static string StringPath = "server=DESKTOP-NLO14PR;Database=GymAction_DB;integrated security=true";
    }
}
